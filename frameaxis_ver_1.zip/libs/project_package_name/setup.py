#!/usr/bin/env python
# encoding: utf-8

from distutils.core import setup

setup(name='project_package_name', 
      version='0.1', 
      description = 'project description', 
      author = '...', 
      packages = ['project_package_name'],
)
