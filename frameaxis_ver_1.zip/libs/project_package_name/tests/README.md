Put tests. Recommended test framework:
[pytest](https://docs.pytest.org/en/latest/)
