Create a package that you can install and use throughout the project. You can
use tools such as [`cookiecutter`](https://github.com/audreyr/cookiecutter). 
